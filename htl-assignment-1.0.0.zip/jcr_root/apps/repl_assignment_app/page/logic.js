use(function () {
    return {
        message3:java.util.Date().toString()
    };
});